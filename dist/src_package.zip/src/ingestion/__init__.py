"""Ingestion package."""
