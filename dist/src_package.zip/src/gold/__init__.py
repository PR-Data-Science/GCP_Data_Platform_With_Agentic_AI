"""Gold layer transforms."""
